/* Added by Martin Thomas */
#ifndef swi_h_
#define swi_h_

/* Prototypes for functions defined in swi_handler.S */
void IntEnable(void);
void IntDisable(void);

#endif
